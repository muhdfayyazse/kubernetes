# Kubernetes_Deep_Dive_NP
A Cloud Guru - Kubernetes Deep Dive

The main sample app is available in the *sample-app* folder.

All other supporting files will be under the lesson folder with the appropriate name.

Enjoy!