Please refer to https://github.com/kubernetes/community/tree/master/contributors/devel/flexvolume.md for documentation.
